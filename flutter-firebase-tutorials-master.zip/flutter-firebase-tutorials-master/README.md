# Flutter firebase tutorials


### Videos

- [Adding Firebase to flutter](https://youtu.be/5bqndRRTvQc) 
- [Flutter Firebase Phone Authentication](https://youtu.be/5bqndRRTvQc) 

### Screenshots

![FlutterFire](https://i.imgur.com/i1UrTx0.png)


### Looking for complete eCommerce Solution 

- http://bit.ly/flutter-ecommerce-firebase

![Shoppers](https://i.imgur.com/c8Ghzt7.png)
